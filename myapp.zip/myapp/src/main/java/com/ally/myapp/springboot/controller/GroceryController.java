package com.ally.myapp.springboot.controller;

import java.util.Collection;
import java.util.HashMap;

import org.springframework.web.bind.annotation.PathVariable; 
import org.springframework.web.bind.annotation.RequestBody; 
import org.springframework.web.bind.annotation.RequestMapping; 
import org.springframework.web.bind.annotation.RequestMethod; 
import org.springframework.web.bind.annotation.RestController;

import com.ally.myapp.springboot.data.GroceryItem;

@RestController
public class GroceryController {

	private HashMap<String, GroceryItem> tempStore = new HashMap<String, GroceryItem>();
	
	@RequestMapping(value = "/groceryitems", method = RequestMethod.POST)
	public GroceryItem create(@RequestBody GroceryItem createThis){
		createThis.setName(createThis.getName());
		tempStore.put(createThis.getName(), createThis);
		return createThis;
	}	
	
	@RequestMapping(value = "/groceryitems/{name}", method = RequestMethod.GET)
	public GroceryItem get(@PathVariable String name){
		return tempStore.get(name);
	}
	
	@RequestMapping(value = "/groceryitems", method = RequestMethod.GET)
	public Collection<GroceryItem> get() {
		return tempStore.values();
	}
	
	@RequestMapping(value = "/groceryitems/{name}", method = RequestMethod.DELETE)
	public String delete(@PathVariable String name){
		String message;
		tempStore.remove(name);
		message = "Removed";
		return message;
	}
}
