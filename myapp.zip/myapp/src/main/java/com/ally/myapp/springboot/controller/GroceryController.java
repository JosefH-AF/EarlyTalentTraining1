package com.ally.myapp.springboot.controller;

import java.util.Collection;
import java.util.HashMap;

import org.springframework.web.bind.annotation.PathVariable; 
import org.springframework.web.bind.annotation.RequestBody; 
import org.springframework.web.bind.annotation.RequestMapping; 
import org.springframework.web.bind.annotation.RequestMethod; 
import org.springframework.web.bind.annotation.RestController;

import com.ally.myapp.springboot.data.GroceryItem;

@RestController
public class GroceryController {

	private HashMap<Long, GroceryItem> tempStore = new HashMap<Long, GroceryItem>();
	
	@RequestMapping(value = "/groceryitems", method = RequestMethod.POST)
	public GroceryItem create(@RequestBody GroceryItem createThis){
		createThis.setId(System.currentTimeMillis());
		tempStore.put(createThis.getId(), createThis);
		return createThis;
	}
	
	@RequestMapping(value = "/groceryitems/{id}", method = RequestMethod.GET)
	public GroceryItem get(@PathVariable Long id){
		return tempStore.get(id);
	}
	
	@RequestMapping(value = "/groceryitems", method = RequestMethod.GET)
	public Collection<GroceryItem> get() {
		return tempStore.values();
	}
	
	
	
}
