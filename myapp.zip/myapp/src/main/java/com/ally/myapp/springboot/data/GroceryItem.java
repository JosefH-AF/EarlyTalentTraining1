package com.ally.myapp.springboot.data;

	public class GroceryItem {
		private String name;
		private int aisle;
		private float price;
		private int count;
		//private long id;

/**		
		public GroceryItem() {
			name = "0";
			aisle = 0;
			price = 0;
			count = 0;
		}
		
		public GroceryItem(String startName, int startAisle, float startPrice, int startCount) {
			name = startName;
			aisle = startAisle;
			price = startPrice;
			count = startCount;
		}
			
			
		public void updateFields(String name, int aisle, float price, int count) {
			setName(this.name);
			setAisle(this.aisle);
			setPrice(this.price);
			setCount(this.count);
		}
		
*/		
		//name
		public String getName() {
			return name;
		}
		
		public void setName(String name) {
			this.name = name;
		}
		
		//aisle
		public int getAisle() {
			return aisle;
		}
		
		public void setAisle(int aisle) {
			this.aisle = aisle;
		}
		
		//price
		public float getPrice() {
			return price;
		}
		
		public void setPrice(float price) {
			this.price = price;
		}
		
		//count
		public int getCount() {
			return count;
		}
		
		public void setCount(int count) {
			this.count = count;
		}
		/**
		public long getId() {
			return id;
		}
		
		public void setId(long id) {
			this.id = id;
		}
		*/
	}
	

